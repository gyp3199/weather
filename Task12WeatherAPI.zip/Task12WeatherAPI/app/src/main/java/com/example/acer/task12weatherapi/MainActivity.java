package com.example.acer.task12weatherapi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    EditText location;
    TextView result;
    String loc;
    GetLocation getLocation;
    ProgressBar pb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        location=(EditText) findViewById(R.id.location_id);
        result=(TextView) findViewById(R.id.result_id);
        pb=findViewById(R.id.progressBar_id);

         loc=location.getText().toString();
    }

    public void click(View view) {
        String loc=location.getText().toString();
        pb.setVisibility(View.VISIBLE);
        getLocation=new GetLocation(MainActivity.this,location,result,pb);
        getLocation.execute(loc);
    }
}
